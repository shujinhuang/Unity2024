﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraCon : MonoBehaviour
{
    public Transform player;//设相机
    private float mouseX, mouseY;//获得鼠标移动的值
    public float mouseSensitivity;//鼠标的灵敏度
    [HideInInspector]
    public float xRotation;//解决mouseY中的GetAxis方法回弹问题定义发变量
    [HideInInspector]
    public Image cursor;//鼠标的光标位置

    public MyPlayer myPlayer;
    
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //获取鼠标左右旋转的值
        mouseX = Input.GetAxis("Mouse X") *mouseSensitivity*Time.deltaTime ;
        //获取鼠标上下旋转的值
        mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;
        

        //实现左右旋转
        player.Rotate(Vector3.up * mouseX);
        //实现上下旋转
        //因为mouseY中的GetAxis方法会返回-1到1之间的浮点数，
        //在鼠标移动的时候数值会随着方向的变化而变化在鼠标不动时数值会回弹到0
        xRotation -= mouseY;
        //限制上下旋转的数值
        xRotation = Mathf.Clamp(xRotation, -70f, 70f);//（限制的对象，最小值，最大值）
        transform.localRotation = Quaternion.Euler(xRotation, 0, 0);
      /*  //锁定鼠标指针到视图中心
        Cursor.lockState = CursorLockMode.Locked;
        //隐藏鼠标
        Cursor.visible = false;

     
        if (Input.GetKeyDown(KeyCode.Equals))
        {
            Cursor.visible = true;
            Debug.Log("显示光标");
            Cursor.lockState = CursorLockMode.None;
        }*/
    }
}
