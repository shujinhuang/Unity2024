﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MyPlayer : MonoBehaviour
{

    private CharacterController cc;//定义CharacterController
    public float moveSpeed=4f;//移动速度
    public float jumpSpeed=6f;//跳跃速度
    private float horizontalMove, verticalMove;//按键值的两个变量
    private Vector3 dir;//控制方向的变量

    public float gravity=9.81f;//重力值

    private Vector3 velocity;//向下掉落的速度

    public Transform groundCheck;//检测点的中心位置
    public float checkRadius;//检测点的半径
    public LayerMask groundLayer;//检测图层级
    public bool isGround;//存储是否碰撞到地面的Bool值
    //音频组件
    private AudioSource footPlayer;


    private void Start()
    {
        //获取Player上的组件CharacterController
        cc = GetComponent<CharacterController>();
        //获取声音组件
        footPlayer = GetComponent<AudioSource>();
       

    }

   

    // Update is called once per frame
    void Update()
    {
        
        //获取按键并加上了速度
        horizontalMove = Input.GetAxis("Horizontal") *moveSpeed;
        verticalMove = Input.GetAxis("Vertical") * moveSpeed;
        //实现移动
          //储存移动的方向的值
        dir = transform.forward * verticalMove + transform.right * horizontalMove;
          //使用CharacterController组件中的Move()方法来进行移动
        cc.Move(dir * Time.deltaTime);
        if (horizontalMove!=0|| verticalMove!=0)
        {
            //移动了就播放脚步声音,并且当前没有播放声音，再进行脚步声音播放
            if ((footPlayer.isPlaying==false)&&isGround==true)
            {
                //播放叫步声
                footPlayer.Play();
            }
        }
        else
        {
            //停止播放
            footPlayer.Stop();
        }

        //实现重力
          //使用Physics中的CheckSphere()方法，方法的描述，如果定义的球体和物体发生碰撞，就返回真(ture)
            //用isGround来存储是否碰撞到地面的Bool值
        isGround = Physics.CheckSphere(groundCheck.position, checkRadius, groundLayer);
        if (isGround && velocity.y < 0)
        {
            velocity.y = -2f;//这个个值可以等于0或0以下的值影响自由落体的手感
        }
        velocity.y -= gravity * Time.deltaTime;
        cc.Move(velocity * Time.deltaTime);//两个Time.deltaTime是时间的二次方

        //跳跃
        if (Input.GetKeyDown(KeyCode.Space)&&isGround)
        {
            velocity.y = jumpSpeed;
        }

        

    }
    

}
